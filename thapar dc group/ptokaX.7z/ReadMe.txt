PtokaX 0.4.1.2
---------------

Homepage: http://www.PtokaX.org

Note: IP-to-Country database file is available on http://ip-to-country.webhosting.info/downloads/ip-to-country.csv.zip .. unpack it to PtokaX/cfg directory.
Note: This PtokaX use Lua 5.1.3 for scripting !
Note: This version have new scripting interface incompatible with all scripts for 0.3.6.0c and older !

PtokaX LUA Scripts forum: http://board.ptokax.ch

PtokaX Wiki: http://wiki.ptokax.ch

Please report all bugs on board or to PPK@PtokaX.org or to me (PPK) on my hub PePeK.czdc.org:4861

Latest PtokaX changelog: http://wiki.ptokax.ch/doku.php?id=changelogs:ptokax:changes_after_0.330_15.31

This application uses the IP-to-Country Database
provided by WebHosting.Info (http://www.webhosting.info),
available from http://ip-to-country.webhosting.info.